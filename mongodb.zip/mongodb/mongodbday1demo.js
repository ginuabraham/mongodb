show dbs
use mydatademo

db.createCollection("students")
show dbs --to check how many databases you have in your database
show collections --to check how many collections are there in your database
db.students.drop()

db.createCollection("students")
show dbs
show collections
db.students.insert({
    "studentno": 1,
    "firstname": "ginu",
    "lastname": "abraham",
    "age":24,
    "dept":"HRD",
    "salary":1000
})
db.students.insertMany([
    { "studentno": 2, "firstname": "linu", "lastname": "abraham", "age":26,"dept":"IT", "salary":2000},
    { "studentno": 3, "firstname": "sunu", "lastname": "abraham", "age":34,"dept":"HRD", "salary":4000},
    { "studentno": 4, "firstname": "minu", "lastname": "abraham", "age":36,"dept":"IT", "salary":3000}
    ])
db.students.find({})
db.students.findOne({})
//find the document where student no is 2
db.students.find({"age":34})
db.students.find({"studentno": 2})
db.students.find({"studentno": 2,"age":26})

db.students.find({},{"firstname": 1})
db.students.find({},{"firstname": 0})
//show firstname 1 or 0 if u want to show only firstname and id also
db.students.find({},{kEY: 1})
db.students.find({},{"firstname": 1})
//WITHOUT ID ONLY NAME TO BE DISPLAYED
db.students.find({},{"firstname": 1, "_id":0})

db.students.remove({"studentno":3})
db.students.find({})

db.students.insert({
     "studentno": 3,
    "firstname": "sunu",
    "lastname": "abraham",
    "age":34
    
})
db.students.find({})
db.students.remove({"_id": ObjectId("5c8f721c769cd23bdc733db4")})
db.students.find({})
db.students.remove({"_id" : ObjectId("5c8f7275769cd23bdc733dbe")})
db.students.find({})
db.students.find({"age":{$gt:24}})
db.students.find({"age":{$ne:34}})
db.students.find({"age":{$gte:24}})
db.students.find({"age":{$lte:34}})

//$or operator where name should be ginu or age is 24
db.students.find({$or:[{"firstname":"ginu"},{"age":24}]})
db.students.find({$or:[{"lastname":"abraham"},{"age":24}]})

//and operator
db.students.find({$and:[{"lastname":"abraham"},{"age":24}]})

//pattern matching
db.students.find({"firstname":/^l/},{"firstname":1,"_id":0})
db.students.find({"lastname":/.m$/},{"firstname":1,"_id":0})

//limit()
db.students.find({}).limit(2)
db.students.find({}).limit(1)
//skip()
db.students.find({}).skip(2)
db.students.find({}).skip(1)
//sort in ascending order
db.students.find({}).sort({"firstname":1})
//sort in descending order
db.students.find({}).sort({"firstname":-1})
db.students.find({}).sort({"age":-1})

//update
db.students.update({"age":24},{$set:{"lastname":"dinu"}})
db.students.find({})
db.students.update({"age":24},{$set:{"age":22}})
db.students.find({})
db.students.update({"age":26},{$set:{"age":22}})
db.students.find({})
db.students.update({"age":22},{$set:{"lastname":"abraham p k"}},{multi:true})
db.students.find({})

db.students.update({"age":34},{$unset:{"lastname":"abraham"}})
db.students.find({})

db.students.aggregate([{$group: { _id: "$dept",salary:{$max: "$salary"}}}])
db.students.aggregate([{$group: { _id: "$dept",salary:{$sum: "$salary"}}}])

db.students.insert({
    "studentno": 3,
    "firstname": "sunu",
    "lastname": "abraham",
    "age":34,
    "dept":"HRD",
    "salary":4000
})
db.students.aggregate([{$group: { _id: "$dept",salary:{$sum: "$salary"}}}])
db.students.find({})

 db.students.remove("_id" : ObjectId("5c908c5485930c1a98ab0fc5")})
 db.students.distinct("dept")
 db.students.count()
 
db.students.find({"salary": {$in: [2000,3000,4000]}})


db.students.update({firstname:"ginu"},{lastname:"abraham",dept:"admin"},{upsert:true})
db.students.find({})

db.students.insert({
    "studentno": 1,
    "firstname": "ginu",
    "lastname": "abraham",
    "age":24,
    "dept":"HRD",
    "salary":1000,
    address:
    {
        street:"67,MGroad",
        city:"Mumbai",
        state:"MS"
    }
})
db.students.find({})
db.students.insertMany([
    { "studentno": 2, "firstname": "linu", "lastname": "abraham", "age":26,"dept":"IT", "salary":2000,
         address:
    {
        street:"67,Cmh",
        city:"pune",
        state:"GS"
    }
    },
    { "studentno": 3, "firstname": "sunu", "lastname": "abraham", "age":34,"dept":"HRD", "salary":4000,
         address:
    {
        street:"67,ram",
        city:"Chennai",
        state:"DC"
    }
    },
    { "studentno": 4, "firstname": "minu", "lastname": "abraham", "age":36,"dept":"IT", "salary":3000,
         address:
    {
        street:"67,Wakad",
        city:"Kerala",
        state:"KS"
    }
    }
    ])
db.students.find({})
db.students.find({"address.city":"Kerala"})

