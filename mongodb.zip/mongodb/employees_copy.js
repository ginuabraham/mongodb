use assignemnt2
db.createCollection("employees")
show dbs
show collections
db.employees.insert({_id:111,firstname:"Anita",lastname:"Gokhle"})
db.employees.find({})
db.employees.insert({_id:333,firstname:"Raja",lastname:"Josji",age:30,salary:80000.0,isEmployee:true})
db.employees.insert({_id:444,firstname:"Santosh",lastname:"Pakhale",age:10,salary:30000.0,isEmployee:false})
db.employees.insert({_id:555,firstname:"Harishwar",lastname:"Mendre"})
db.employees.insert({_id:222,firstname:"Vaishali",lastname:"Joshi",age:23,salary:22000.0,isEmployee:true})
db.employees.find({})

db.employees.insert([
    		{
		 firstname:"Tanmaya",
  		 lastname:"Acharaya",
  	 	 gender:"Male",
  		 age:50,
  		 salary:90000.0,
  		 address:
		 {
			street:"44,Whitefield",
			city:"Banglore",
			state:"KS"
		 },
		 contacts:["9878666666","030-34556"]
    		},
    		{
			 firstname:"shilpa",
  			 lastname:"bhosale",
  			 gender:"Male",
  	 		 age:60,
  	 		 salary:45000.0,
  	 		 address:
	 		 {
				street:"67,MGRoad",
				city:"Mumbai",
				state:"MS"
	 		 },
	 		contacts:["88888108810","020-787777"]
    		},
    		{
			 firstname:"Kadiresan",
  			 lastname:"K",
  	 		 gender:"Male",
  	 		 age:29,
  	 		 salary:80000.0,
  	 		 address:
			 {
				street:"Sipcot",
				city:"Chennai",
				state:"TS"
			 },
			 contacts:["7786666666","044-878888"]
   		 },
		{
			 firstname:"Rahul",
  			 lastname:"Kulkarni",
  	 		 gender:"Male",
  	 		 age:34,
  	 		 salary:32000.0,
  	 		 address:
			 {
				street:"Aundh",
				city:"Pune",
				state:"MS"
			 },
			 contacts:["9889788864","99-888679"]
   		 }
	])
	db.employees.find({})
	//1)Fetch employees based on unique id value
	db.employees.find({"_id" : ObjectId("5c8f8413769cd23bdc733e01")})
	db.employees.find({})
    db.employees.find({"_id" : ObjectId("5c8f8413769cd23bdc733e02")})
	db.employees.find({})
	db.employees.find({"_id" : ObjectId("5c8f8413769cd23bdc733e03")})
		
//2)show all employee details without firstname, lastname, address field	
db.employees.find({},{"firstname":0,"lastname":0,"address":0}).pretty()

//3)Add array of employee objects
db.employees.insert([{firstname:"vrushali",lastname:"Tambe",age:30,salary:12000.0,isEmployee:false},
	{firstname:"sameer",lastname:"kanase",age:24,salary:15000.0,isEmployee:true}])
	db.employees.find({})	
	
	//4)Find all data with pretty function
		db.employees.find().pretty()
		
		//5)Remove all records
		
		db.employees.remove({})
		db.employees.insert([
    		{
		 firstname:"Tanmaya",
  		 lastname:"Acharaya",
  	 	 gender:"Male",
  		 age:50,
  		 salary:90000.0,
  		 address:
		 {
			street:"44,Whitefield",
			city:"Banglore",
			state:"KS"
		 },
		 contacts:["9878666666","030-34556"]
    		},
    		{
			 firstname:"shilpa",
  			 lastname:"bhosale",
  			 gender:"Male",
  	 		 age:60,
  	 		 salary:45000.0,
  	 		 address:
	 		 {
				street:"67,MGRoad",
				city:"Mumbai",
				state:"MS"
	 		 },
	 		contacts:["88888108810","020-787777"]
    		},
    		{
			 firstname:"Kadiresan",
  			 lastname:"K",
  	 		 gender:"Male",
  	 		 age:29,
  	 		 salary:80000.0,
  	 		 address:
			 {
				street:"Sipcot",
				city:"Chennai",
				state:"TS"
			 },
			 contacts:["7786666666","044-878888"]
   		 },
		{
			 firstname:"Rahul",
  			 lastname:"Kulkarni",
  	 		 gender:"Male",
  	 		 age:34,
  	 		 salary:32000.0,
  	 		 address:
			 {
				street:"Aundh",
				city:"Pune",
				state:"MS"
			 },
			 contacts:["9889788864","99-888679"]
   		 }
	])
	
		db.employees.find({})
		db.employees.remove({ "firstname":"Rahul"},1)
		db.employees.find({})
		//7)Find Documents with firstname Rahul
		
		db.employees.find({firstname:"Rahul"})
		
		//8)Find the documents for those whose age is greater than 40
		
		db.employees.find({age:{$gt:40}})
		//9)Find firstname lastname and age for those employee having 
		//age greater than 50 with first 5 record
		
		db.employees.find({age:{$gt:50}},{firstname:1,lastname:1,age:1}).limit(5).pretty()
		//1) Update age of all records having firstname "shilpa" age to 33
		db.employees.update({"firstname":"shilpa"},{$set:{"age":33}},{multi:true})	
		db.employees.find({})
		
		
		//2)Update Tanmaya with food like array like foodILike:["pizza","idali"]
			
		db.employees.update({"firstname":"Tanmaya"},{$set:{"foodLike":["pizza","idali"]}})	
		db.employees.find({})
		
		//3)Update existing record.Push one more entry in  array of  foodILike 
		db.employees.update({"firstname":"Tanmaya"},{$push:{"foodLike":"Rice"}})
		db.employees.find({})
			
		//4)pull data from foodILike array for Tanmaya irrespective of location
		db.employees.update({"firstname":"Tanmaya"},{$pull:{"foodLike":"pizza"}})
		db.employees.find({})
		
		db.employees.update({"firstname":"Tanmaya"},{$push:{"foodLike":"pea"}})
		db.employees.update({"firstname":"Tanmaya"},{$push:{"foodLike":"pizza"}})
		//pullAll
		db.employees.update({"firstname":"Tanmaya"},{$pullAll:{"foodLike":["idali","Rice","pea","pizza"]}})
		
		//addtoset
		db.employees.update({"firstname":"Tanmaya"},{$addToSet:{"foodLike":"pizza"}})
		
		
		//5)Find the document  with city "Chennai"
		db.employees.find({"address.city":"Chennai"})
		db.employees.find({})
		
		
		
		//6)Update Shilpa's Gender
		db.employees.update({"firstname":"shilpa"},{$set:{"gender":"Female"}})
		
		//7)  Find First 2 documents from employee
		db.employees.find({}).limit(2)
		
		//9)Find the employees having matching salary   as 2000  or 45000
        db.employees.find({"salary": {$in: [2000,45000]}})
		
		//8)  Print Reports of employee Name and salary
		db.employees.find({}).forEach(function(doc)
		{
		    print("Employee Name: "+doc.firstname+" "+"Salary : "+doc.salary)
		}
		)
		
		//10Find record having age <34 Or salary greater than 5000
		db.employees.find({$or:[{"age":{$lt:34}},{"salary":{$gt:5000}}]})
		
		//11)Find record having age <34 and salary greater than 5000
		db.employees.find({$and:[{"age":{$lt:34}},{"salary":{$gt:5000}}]})
		db.employees.find({})
		
		//12)Find all male  employees staying in "chennai"
		db.employees.find({$and:[{"gender":"Male"},{"address.city":"Chennai"}]})
		
		db.employees.find({})
		
		//13)Find all employee having given all contacts
        db.employees.find({contacts: {$all: ["7786666666","044-878888"]}}).count()
        
        	db.employees.find({})
        	db.employees.aggregate([{$match:{"gender":"Male"}}])
    
     //only male
     db.employees.find({gender: {$all: ["Male"]}}).count()
     
     //16)Show Count of Only male from employees
     db.employees.find({gender: {$all: ["Female"]}}).count()
     
      //15)Show Count Of Male and Female from employees 
     db.employees.aggregate([{$group: { _id: "$gender", total : {$sum:1}}}])
     
     //17)Find firstname    lastname and age for those employee having 
        // Age greater than 50 with first 5 record
       db.employees.find({$or:[{"age":{$gt:49}}]},{"firstname":1,"lastname":1 ,"age":1, "_id":0})
       
     //18)Convert last name in Uppercase and sort in ascending order  
    db.employees.aggregate([{ $project:{lname:{$toUpper:"$lastname"},_id:0}},{$sort:{lname:1}}])
    
    db.employees.update({"firstname":"Tanmaya"},{$set:{"dept":["IT"]}})	
    	db.employees.find({})
    db.employees.update({"firstname":"Kadiresan"},{$set:{"dept":["HRD"]}})	
    	db.employees.find({})
    	db.employees.update({"firstname":"shilpa"},{$set:{"dept":["HRD"]}})	
    		db.employees.find({})
    //19)Find Department wise Maximum salary
    db.employees.aggregate([{$group:{_id: "$dept",maxSal: {$max:"$salary"}}}])
   
    
    
    
    //1)find the employees information whose salary is greater than 70000
    // and check for employee exists and then print the next values . 
    var Cursor=db.employees.find({salary:{$gt:70000}})
    Cursor.next()
    
    
    // 2)display firstname from employees collection  using forEach
    //forEach() method
    db.employees.find().forEach(function(employees)
    { 
        var detail= "Employee Name="+employees.firstname ;
        print(detail);
    })

    //3)display the firstname of the employee who stays in city Mumbai
    
    db.employees.find({"address.city":"Mumbai"}).forEach(function(employees)
    { 
        var details= "Employee Name="+employees.firstname ;
        print(details);
    })


		