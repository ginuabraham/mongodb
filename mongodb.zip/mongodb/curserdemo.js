use curserdemo
db.createCollection("emp")
db.emp.find({})
db.emp.insert([
	{  
	         "_id" : ObjectId("55cc8833211cb7f01f58ce20"),  
	         "Name" : "Pankaj Choudhary",  
	         "City" : "Alwar",  
	         "Salary" : 35000  
	 } , 
	 {  
	         "_id" : ObjectId("55cc8850211cb7f01f58ce21"),  
	         "Name" : "Sandeep Jangid",  
	         "City" : "Jaipur",  
         "Salary" : 25000  
    } , 
	 {  
        "_id" : ObjectId("55cc8868211cb7f01f58ce22"),  
	         "Name" : "Rahul Prajapat",  
	         "City" : "Delhi",  
	         "Salary" : 27000  
	 },  
    {  
        "_id" : ObjectId("55cc887b211cb7f01f58ce23"),  
	         "Name" : "Sanjeev Baldia",  
         "City" : "Delhi",  
        "Salary" : 47000  
    },  
	 {  
         "_id" : ObjectId("55cc8895211cb7f01f58ce24"),  
         "Name" : "Narendra Sharma",  
        "City" : "Jaipur",  
         "Salary" : 35000  
    },  
	 {  
	         "_id" : ObjectId("55cc88b0211cb7f01f58ce25"),  
	         "Name" : "Omi Choudhary",  
         "City" : "Alwar",  
	         "Salary" : 27000  
	 } , 
	 {  
        "_id" : ObjectId("55cc88f5211cb7f01f58ce27"),  
         "Name" : "Nitin Yadav",  
         "City" : "Jaipur",  
	         "Salary" : 32000  
     } ] 
    )
    
    db.emp.find({})
    
    //count()
    db.emp.find({}).count()
    
     db.emp.count()
    
    db.emp.find({Salary:{$gt:30000}}).count()
    
    db.emp.find({Salary:{$gt:30000}}).limit(2).count()
    
    db.emp.find({Salary:{$gt:30000}}).limit(2).count(true)
    
    db.emp.find().limit(3).pretty()
    
    db.emp.find({City:"Delhi"}).limit(2).pretty() 
    
    db.emp.find().skip(3).pretty()
    
    db.emp.find().limit(2).skip(1).pretty()
    
    db.emp.find().sort({"Salary":1}).pretty()
    
   db.emp.find().sort({"Salary":1,"City":-1}).pretty()
   
   db.emp.find({},{_id:0,Name:1,Salary:1}).sort({City:1}).limit(4).pretty()
    
    db.emp.find({},{_id:0,Name:1,Salary:1,City:1}).sort({$natural:1}).pretty()
    
    db.emp.find({},{_id:0,Name:1,Salary:1,City:1}).sort({$natural:-1}).pretty()
    
    //In this query we assign the reference into the Cursor1 object returned by the find() method.
    var Cursor1=db.emp.find()
    
    //This query returns the first document from the cursor object.
    Cursor1.next()
    
    //This query returns the next (second) document from the cursor object.
    Cursor1.next()
    
    //toArray
    db.emp.find({},{_id:0,Name:1,Salary:1}).toArray()
    
    //Use Array variable
	var Array_=db.emp.find({},{_id:0,Name:1,Salary:1}).toArray()
	if(Array_.length>0)  
	{  
        Array_   
    }  
    
    //return a specific document from an Array variable.
    var Array_=db.emp.find({},{_id:0,Name:1,Salary:1}).limit(3).toArray()  
    if(Array_.length>0)  
	{  
	   printjson(Array_[1])  
	}  
    
    //Difference b/w db.collection.find() and db.collection.find().toArray() methods
    //DBQuery.shellBatchSize
    DBQuery.shellBatchSize =4
    db.emp.find({},{_id:0,Name:1})
    
    db.emp.find({},{_id:0,Name:1}).toArray()
    
    //Count all documents
    db.emp.find({},{_id:0,Name:1}).size()
    
    //limit()
    db.emp.find({},{_id:0,Name:1}).limit(4).size()
    
    //skip()
    db.emp.find({Salary:{$gt:25000}}).skip(3).size()
    
    //size() method with skip() and limit() methods
    db.emp.find({Salary:{$gt:25000}}).limit(2).skip(1).size()
    
    //hasNext() method
    db.emp.find().hasNext()
    
    //1st type
    var nxt=db.emp.find().limit(2)
    var value=nxt.hasNext()?"Cursor conatin more document":"Cursor doesn't contain more document"
    if(value)
    {
        printjson(value) 
        
    }

    //2nd type
    var nxt1=db.emp.find().limit(2)
    var value1=nxt1.hasNext()?nxt1.next():null
    if(value1)
    { 
        printjson(value1)
    }
    
    //forEach() method
    db.emp.find().forEach(function(emp)
    { 
        var detail= "Employee Name="+emp.Name +
        "Employee Salary=" +emp.Salary;
        print(detail);
    })


    //Explain() Method
    
    //Explain() method with queryPlanner Mode
    db.emp.find().explain("queryPlanner")
    
    
    //Explain() method with executionStatsMode
    db.emp.find().explain("executionStats")
    
    //Explain() method with allPlansExecution
    db.emp.find().explain("allPlansExecution")
    
    
    
    
    
    
    
    


    
    
    
    
