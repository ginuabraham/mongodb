use indexdemo
db.post.insert( 
    
    [{ "_id" : ObjectId("55c545e1acae58b1a7d7dff1"), "Likes" : 5 } , 
{ "_id" : ObjectId("55c54617acae58b1a7d7dff2"), "Likes" : 4 },  
{ "_id" : ObjectId("55c54665acae58b1a7d7dff3"), "Likes" : 4 }  ,
{ "_id" : ObjectId("55c546a6acae58b1a7d7dff4"), "Likes" : 5 }  ,
{ "_id" : ObjectId("55c546d9acae58b1a7d7dff5"), "Likes" : 3 } , 
{ "_id" : ObjectId("55c54711acae58b1a7d7dff6"), "Likes" : 6 } ]
    )
    
db.post.find({})

db.post.getIndexes()
//status of index
db.post.find({Likes:1}).explain('executionStats')
db.post.createIndex({Likes:1})


//collection post1
db.post1.insert({
 
    "_id": ObjectId("55c545e1acae58b1a7d7dff1"),  
    "PostBY": "Pankaj choudhary",  
    "Time": ISODate("2015-08-07T23:57:21.041Z"),  
    "Title": "Introduction of MongoDB",  
    "Tags": [  
        "NoSQL",  
        "MongoDB",  
        "Database"],  
    "Likes": 5,  
    "Comment": {  
        "CommentBy": "Rahul",  
        "Text": "Nice Article"  
    }} )
    
    db.post1.find({})
    //index on embedded field
    db.post1.createIndex({"Comment.CommentBy":1})
    
    //index for Tags field
    db.post1.createIndex({"Tags":-1})
    
     //index for Comments field
      db.post1.createIndex({"Comment":1})
        
    //Compound multikey indexes
     db.post1.createIndex({"Comment":-1,"Tags":1})
    db.post1.createIndex({"Comment":1,Title:-1})
    
    db.post1.createIndex({"Comment":1,Title:-1,PostBy:1})
     
    db.post1.drop()
    db.post1.insert(
    
       {  "_id": ObjectId("55c54711acae58b1a7d7dff6"),  
    "PostBY": "Pankaj choudhary",  
    "Time": ISODate("2015-08-08T00:02:25.968Z"),  
    "Title": "MongoDB Day3",  
    "Tags": [  
        "NoSQL",  
        "MongoDB",  
        "Database"],  
    "Likes": 6,  
    "Comment": [{  
        "CommentBy": "Neeraj",  
        "Text": " Nice One"  
    },
    {  
        "CommentBy": "Rahul",  
        "Text": "Thanks to Share"  
    }]
           
        })
        
    //error
    db.post1.createIndex({"Comment":-1,"Tags":1})
    
    

    
   
    