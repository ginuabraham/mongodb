use CgProductDB
db.createCollection("ProductCollection")
db.ProductCollection.insert([{ _id:1,
    item:"Laptop",prodCat :"Electronics",
    price:30000.0,
    quantity: 2,
    orderInfo:
        {_id:"O001",
        orderdate: ISODate("2014-01-01"),
        address:{street:"66,Airoli",
        city:"Mumbai",
        state:"MS",
        zipcode:700987,
        coords: [ -73.856077, 40.848447 ]},
    email:"capgemini@capgemini.com",
    mobiles:[8888108810]}}])

db.ProductCollection.insert([{ _id:2,
item:"Mobile",prodCat :"Electronics",
price:15000.0,quantity: 10,
orderInfo:{"_id":"O002",
"orderdate" : ISODate("2010-03-12"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"icres@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.insert([{ _id:5,
item:"TV",prodCat :"Electronics",
price:24000.0,quantity: 10,
orderInfo:{"_id":"O003",
"orderdate" : ISODate("2012-06-17"),
address:{street:"GT Road",city:"Sahibabad",
state:"UP",zipcode:567777,coords: [ -11.80007, 13.1123456 ]},
email:"techm@techm.com",mobiles:[7865452222]}}])

db.ProductCollection.insert([{ _id:6,
item:"Bangles",prodCat :"Jewellery",
price:4000.0,quantity: 1,
orderInfo:{"_id":"O004",
"orderdate" : ISODate("2010-05-16"),
address:{street:"Salt Lake",city:"Kolkata",
state:"West Bengol",zipcode:222224,
coords: [ -67.850007, 9.456666 ]},
email:"vaishali@gmail.com",mobiles:[8888108850,9402312123]}}])

db.ProductCollection.insert([{ _id:3,
item:"Necklace",prodCat :"Jewellery",
price:5000.0,quantity: 12,
orderInfo:{"_id":"O005",
"orderdate" : ISODate("2010-05-17"),
address:{street:"City Lake",city:"Kolkata",
state:"West Bengol",zipcode:222224,
coords: [ -68.850007, 8.456666 ]},
email:"vaishali@gmail.com",mobiles:[8988108850,9482312123]}}])

db.ProductCollection.insert([{ _id:4,
item:"Necklace",prodCat :"Jewellery",
price:5000.0,quantity: 12,
orderInfo:{"_id":"O006",
"orderdate" : ISODate("2010-05-27"),
address:{street:"Abc Lake",city:"Ernakulam",
state:"Kerala",zipcode:222224,
coords: [ -68.850007, 8.456666 ]},
email:"abc@gmail.com",mobiles:[8988008850,9482302123]}}])


db.ProductCollection.insert([{ _id:7,
item:"Churidar",prodCat :"Clothing",
price:5000.0,quantity: 12,
orderInfo:{"_id":"O007",
"orderdate" : ISODate("2010-03-27"),
address:{street:"Abc Lake",city:"Ernakulam",
state:"Kerala",zipcode:222224,
coords: [ -58.850007, 6.456666 ]},
email:"abc@gmail.com",mobiles:[8988008850,9482302123]}}])

db.ProductCollection.insert([{ _id:8,
item:"Oil",prodCat :"Stationary",
price:10000.0,quantity: 8,
orderInfo:{"_id":"O008",
"orderdate" : ISODate("2010-03-27"),
address:{street:"Abc Lake",city:"Ernakulam",
state:"Kerala",zipcode:222224,
coords: [ -58.850007, 6.456666 ]},
email:"stat@gmail.com",mobiles:[8988008850,9482302123]}}])

db.ProductCollection.insert([{ _id:9,
item:"CD",prodCat :"Electronics",
price:1000.0,quantity: 10,
orderInfo:{"_id":"O009",
"orderdate" : ISODate("2010-03-02"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"ic@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.insert([{ _id:10,
item:"Salwar",prodCat :"Clothing",
price:9000.0,quantity: 10,
orderInfo:{"_id":"O0010",
"orderdate" : ISODate("2010-03-02"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"ic@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.insert([{ _id:12,
item:"Wheat",prodCat :"Stationary",
price:45000.0,quantity: 10,
orderInfo:{"_id":"O0012",
"orderdate" : ISODate("2010-03-02"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"ic@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.insert([{ _id:13,
item:"Wheat",prodCat :"Stationary",
price:55000.0,quantity: 10,
orderInfo:{"_id":"O0013",
"orderdate" : ISODate("2010-03-02"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"ic@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.insert([{ _id:14,
productName:"Atta",prodCat :"Stationary",
price:55000.0,quantity: 31,
orderInfo:{"_id":"O0014",
"orderdate" : ISODate("2010-03-02"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"ic@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.insert([{ _id:15,
productName:"Chain",prodCat :"Jewellery",
price:5000.0,quantity: 32,
orderInfo:{"_id":"O0015",
"orderdate" : ISODate("2010-03-02"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"ic@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.insert([{ _id:16,
productName:" Fan",prodCat :"Electronics",
price:5000.0,quantity: 32,
orderInfo:{"_id":"O0016",
"orderdate" : ISODate("2010-03-02"),
address:{street:"FC Road",city:"Pune",
state:"MS",zipcode:40081,coords: [ -23.80007, 30.1123456 ]},
email:"ic@ibm.com",mobiles:[9856342189]}}])

db.ProductCollection.find({})


//Lab 1

//1.4-	Fetch the product based on unique product id.
db.ProductCollection.find({}).pretty()

//1.5-	Fetch all product details except coord , email .
db.ProductCollection.find({},{"coords":0,"email":0}).pretty()

//1.6-	Add the orderstatus = “pending”  field for product id  “3” 
db.ProductCollection.update({"_id":3},{$set: {"orderstatus":"pending"}})
db.ProductCollection.find({"_id":3})

//1.7-	Update the product price by 5000 for product name  “Laptop”
db.ProductCollection.update({"item":'Laptop'},{$set: {"price":5000}})
db.ProductCollection.find({"item":'Laptop'})

//1.8-	Update the product price by 5000 for  all product having product name  “Laptop”
db.ProductCollection.update({"item":'Laptop'},{$set: {"price":5000}})
db.ProductCollection.find({"item":'Laptop'})

//1.9-	Add one more mobile number in mobiles field of order information for order id  “2”
db.ProductCollection.update({"_id":2},{$push: {"orderInfo.mobiles":6856342187}})
db.ProductCollection.find({"_id":2})


//1.10- Update the product price to “40.00 “and product category to “electronics”  
//for the product having item name “CD”. Insert the product if it is not existing.
db.ProductCollection.update({"item":'CD'},{$set: {"price":40.00,"prodCat":"Electronics"}})
db.ProductCollection.find({"item":'CD'})

//1.11- Rename “item” field  to “productName” in the above collection
db.ProductCollection.updateMany({}, {$rename: {"item": "productName"}})
db.ProductCollection.find({})

//1.12-	Remove the product with _id=4.
db.ProductCollection.remove({"_id":4})
db.ProductCollection.find({})

//1.13-	Remove all products which product name  starts with "C"
db.ProductCollection.remove({"productName":/^C/})
db.ProductCollection.find({})

//1.14-	Find the product having   productType   as either “Electronics” OR “TV”
db.ProductCollection.find({$or: [{prodCat: "Electronics"},{productName:"TV"}]})

//1.15-	Show the list of those product having price greater than 40000.
db.ProductCollection.find({price:{$gt: 40000}})

//1.16-	Display only product name, product type and product price for those product having price greater than 40000.
db.ProductCollection.find({price:{$gt: 40000}},{_id:0,productName:1,prodCat:1,price:1})

//1.17-	Display only product name, product type and product price for those product having price greater than 40000. 
//But show only first 3  documents
db.ProductCollection.find({price:{$gt: 40000}},{_id:0,productName:1,prodCat:1,price:1}).limit(3)

//1.18-	Find all documents which  are delivered in state “MS”
db.ProductCollection.aggregate([{$match: {"orderInfo.address.state": "MS"}}])

//1.19-	Sort products as per price in descending order.
db.ProductCollection.aggregate([{$sort: {price:-1}}])

//1.20-	Sort product as per product category.
db.ProductCollection.aggregate([{$sort: {prodCat:1}}])

//1.21-	Display only first 3 products
db.ProductCollection.find({}).limit(3)

//1.22-	 Create product order report as follows.
//Display-
//Product Name: ____   Product Category: ________ Product Price:_____   Order Date:______    Order State:_______
db.ProductCollection.find().forEach(function(pro)
{
    var prodetails= "Product Name: "+pro.productName +" Product Category: " 
    +pro.prodCat+ " Price: "+pro.price+ " Order Date: " +pro.orderInfo.orderdate 
    + " Order State: "+ pro.orderstate;
    print(prodetails);
    
})

//1.23- Find the products document maching state in “MS”  OR “UP”.
db.ProductCollection.aggregate([{$match: {$or: [{"orderInfo.address.state": "MS"},{"orderInfo.address.state": "MS"}]}}])

//1.24 Find those products havine price >40000 and delivered in state “MS”.
db.ProductCollection.find({$and: [{"price":{$gt: 40000}},{"orderInfo.address.state": "MS"}]})

//1.25 Find List of all “electronics” delivered in city “Pune”
db.ProductCollection.find({$and: [{prodCat: "Electronics"},{"orderInfo.address.city": "Pune"}]})

//1.26.	Sort the product by product category in ascending order and print it one by one using cursor.
var Cursor1=db.ProductCollection.find({}).sort({"prodCat":1})
Cursor1.next()
Cursor1.next()
Cursor1.next()
Cursor1.next()

//Lab 2

//2.1- Display the product with “electronic” category.
db.ProductCollection.find({prodCat: "Electronics"})

//2.2-Group the product category wise and display the count. 
db.ProductCollection.aggregate([{$group: { _id: "$prodCat",total:{$sum:1}}}]).count()

//2.3-	Display how many number of products available for “Jewellery” category.
 db.ProductCollection.find({prodCat: {$all: ["Jewellery"]}}).count()

//2.4- Calculate the average amount and average quantity for each category of product.
db.ProductCollection.aggregate([
    {$group:  {
    _id : "$prodCat" ,
    AveragePrice: {$avg: "$price"},
    Averagequantity: {$avg: "$quantity"}
    }   
}])


//2.5- Find product name, product category, price  for those product having quantity greater than 30.
//Show only first 3 record.
db.ProductCollection.find({"quantity":{$gt: 30}},{"productName":1, "prodCat":1, "price":1}).limit(3)

// 2.6-Sort the product quantity wise in ascending order
db.ProductCollection.find().sort({"quantity":1})

//2.7- Display the sum of total sale price category wise.
db.ProductCollection.aggregate([{$group :{ _id : "$prodCat",TotalPrice:{$sum: "$price"}}}])

//2.8-Find out which product is most selling product.
db.ProductCollection.aggregate([{$group: { _id: "$productName",maxPrice: {$max: "$price"}}}])

//2.9- Find the product list which was ordered in year “2010”
//db.ProductCollection.find({"oderInfo.orderdate": {$year: "2010"}})

























